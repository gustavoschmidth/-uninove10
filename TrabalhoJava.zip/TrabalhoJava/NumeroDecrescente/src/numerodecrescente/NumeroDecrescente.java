package numerodecrescente;

import java.util.Scanner;

public class NumeroDecrescente {

    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);

        int num1;

        String entrada;

        //Leitura do Primeiro Número
        System.out.println("Digite o Número:");
        entrada = in.next();
        num1 = Integer.parseInt(entrada);

        if (num1 < 0) {
            System.out.println("Número Inválido");
        }
        while (num1 > 0) {
            System.out.println(num1);
            num1--;
        }
    }
}