/*
c. crie uma classe CamaroteInferior (que possui a localização do
ingresso e métodos para acessar e imprimir esta localização)
 */
package ingresso;

public class CamaroteInferior extends Vip{
    
    private double valorCamInf = 150;
    private double totalCamInf;
    private String localizacao;

    /*
    public void setValorCamInf(double valorCamInf) {
        this.valorCamInf = valorCamInf;
    }
    */
    
    public double getValorCamInf() {
        return valorCamInf;
    }
    
    public double getTotalCamInf() {
        this.totalCamInf = getValorCamInf() + valorAdicional;
        return totalCamInf;
    }

    /**
     * @return the localizacao
     */
    public String getLocalizacao() {
        return localizacao;
    }
    
}
