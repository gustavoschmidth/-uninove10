/*
b. crie uma classe Normal, que herda Ingresso e possui um método
que imprime: "Ingresso Normal".
 */
package ingresso;

public class Normal extends Ingresso{
    
    private double ingressoNormal = 50;

    public double getIngressoNormal() {
        return ingressoNormal;
    }

   
}
