/*
CamaroteSuperior que é mais cara (possui valor adicional). Esta última possui
um método para retornar o valor do ingresso. Ambas as classes herdam a classe Vip
 */
package ingresso;

public class CamaroteSuperior extends Vip{
    
    private double valorCamSup = 200;
    private double totalCamSup;

    /*
    public void setValorCamSup(double valorCamSup) {
        this.valorCamSup = valorCamSup;
    }
    */
    
    public double getValorCamSup() {
        return valorCamSup;
    }
    
    public double getTotalCamSup() {
        this.totalCamSup = getValorCamSup() + valorAdicional;
        return totalCamSup;
    }

    

    

    
    
}
