/*
4. Escreva um programa em Java com uma classe chamada Ingresso que
possui um valor em reais e um método denominado imprimeValor().
a. crie uma classe Vip, que herda Ingresso e possui um valor adicional.
Crie um método que retorne o valor do ingresso Vip (com o adicional
incluído).
b. crie uma classe Normal, que herda Ingresso e possui um método
que imprime: "Ingresso Normal".
c. crie uma classe CamaroteInferior (que possui a localização do
ingresso e métodos para acessar e imprimir esta localização) e uma
classe CamaroteSuperior, que é mais cara (possui valor adicional).
Esta última possui um método para retornar o valor do ingresso.
Ambas as classes herdam a classe Vip.
 */
package ingresso;
import java.util.Scanner;

public class Ingresso{
    
    private double imprimeValor;
    
    public static void main(String[] args) {

        int opcao;
        String entrada;
        String fileira = null;
        String poltrona;

        System.out.println("------------VALOR DO INGRESSO NORMAL = R$50,00------------");
        System.out.println("Escolha a opção da compra do ingresso pelo setor: ");
        System.out.println("1 - NORMAL ");
        System.out.println("2 - VIP ");
        System.out.println("3 - CAMAROTE INFERIOR");
        System.out.println("4 - CAMAROTE SUPERIOR");
        
        Scanner in = new Scanner(System.in);
        entrada = in.next();        
        opcao = Integer.parseInt(entrada);       
       
        switch (opcao) {
            
            //se selecionado a opção 1, será executado o comando de compra normal
            case 1:
                Normal normal1 = new Normal();
                normal1.getIngressoNormal();
                System.out.println("O valor do seu ingresso é: " + normal1.getIngressoNormal());
                break;
            
            //se selecionado a opção 2, será executado o comando para VIP
            //com o adicional de 100 reais
            case 2:
                Vip vip1 = new Vip();
                vip1.setValorAdicional(100);
                System.out.println("o valor do ingresso VIP é: " + vip1.getValorVip() + " com o adicional fica no total de: " + vip1.getTotalValorVip());
                break;
            
            case 3:
                CamaroteInferior camInf1 = new CamaroteInferior();
                camInf1.setValorAdicional(150);
                System.out.print("Qual a letra correspondente da fileira: ");
                fileira = in.next();
                System.out.print("Qual o número da poltrona: ");
                poltrona = in.next();
                System.out.println("o valor do ingresso para Camarote Inferior é: " + camInf1.getTotalCamInf());
                System.out.println("A localização do ingresso é: " + fileira + "-" + poltrona);
                break;

            case 4:
                CamaroteSuperior camSup1 = new CamaroteSuperior();
                camSup1.setValorAdicional(200);
                System.out.print("Qual a letra correspondente da fileira: ");
                fileira = in.next();
                System.out.print("Qual o número da poltrona: ");
                poltrona = in.next();
                System.out.println("o valor do ingresso para Camarote Superior é: " + camSup1.getTotalCamSup());
                System.out.println("A localização do ingresso é: " + fileira + "-" + poltrona);
                break;

            default:
                System.out.println("Opção de Ingresso Inválido");
           
        }
    
    }

}
        
        
       
        
       
