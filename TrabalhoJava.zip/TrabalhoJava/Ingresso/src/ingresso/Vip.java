/*
a. crie uma classe Vip, que herda Ingresso e possui um valor adicional.
Crie um método que retorne o valor do ingresso Vip (com o adicional
incluído)
 */
package ingresso;

public class Vip extends Ingresso{
    
    private double valorVip = 100;
    public double valorAdicional;
    private double totalValorVip;
    private String fileira;
    private int poltrona;

    public double getValorVip() {
        return valorVip;
    }
    
    public void setValorAdicional(double valorAdicional){
        this.valorAdicional = valorAdicional;
    }
    
    public double getValorAdicional() {
        return valorAdicional;
    }
    
    public double getTotalValorVip() {
        
        this.totalValorVip = getValorVip() + valorAdicional;
        return this.totalValorVip;
    }

    public String getFileira() {
        return fileira;
    }

    public void setFileira(String fileira) {
        this.fileira = fileira;
    }

    public int getPoltrona() {
        return poltrona;
    }

    public void setPoltrona(int poltrona) {
        this.poltrona = poltrona;
    }
    



    
}
