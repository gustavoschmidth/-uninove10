
package connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

public class ConnectionFactory {
    
    private static final String DRIVER = "com.mysql.jdbc.Driver";
    private static final String URL = "jdbc:mysql://localhost:3306/agenda";
    private static final String USER = "root";
    private static final String PASS = "";
    public static String sql;

    public static void salvar(String nome, String sobrenome, Date dtNascimento){
        Connection conn = null;
        try {
            
            conn = getConnection();
            
            String query = " insert into contato (NOME, SOBRENOME, DATA_NASC) values (?, ?, ?)";    

                PreparedStatement preparedStmt = conn.prepareStatement(query);
                preparedStmt.setString (1, nome);
                preparedStmt.setString (2, sobrenome);
                preparedStmt.setDate (3, (java.sql.Date) dtNascimento);

                preparedStmt.execute();
                preparedStmt.close();

        } catch (Exception e) {
            
        }finally{
            closeConnection(conn);      
        }
       
    }


    
    public static Connection getConnection(){
        try {
            
            Class.forName(DRIVER);
            
                return DriverManager.getConnection(URL, USER, PASS);
            
        } catch (ClassNotFoundException | SQLException ex) {
            
            throw new RuntimeException("erro na conexão", ex);
                    
                        
        }
    }
    
 
    public static void closeConnection (Connection conn){
        
        if (conn != null)
            
            try {
                conn.close();
        } catch (SQLException ex) {
            System.err.println("Erro" + ex);
        }
        
    }
    
    public static void closeConnection (Connection conn, PreparedStatement stmt){
        
        if (stmt != null)
            
            try {
                
                stmt.close();
                
            } catch (SQLException ex) {
                
                System.err.println("Erro" + ex);
                
        }
        
        closeConnection(conn);
        
    }
    
    public static void closeConnection (Connection conn, PreparedStatement stmt, ResultSet rs){
        
        if (rs != null)
            
            try {
                
                rs.close();
                
            } catch (SQLException ex) {
                
                System.err.println("Erro" + ex);
                
        }
        
        closeConnection(conn, stmt);
        
    }
     
}
