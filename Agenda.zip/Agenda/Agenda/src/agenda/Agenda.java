
package agenda;

import connection.ConnectionFactory;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Agenda {

    public static Connection conn;
    public static PreparedStatement ps;
    public static ResultSet rs;
    public static String sql;
    public static String usuario = "root";
    public static String senha = "";
    
    public static void main(String[] args) throws SQLException {
        cadastrar();
        consultar();
    }
    
    public static void cadastrar(){
        try {
         
            String nome;
            String sobrenome = null;
            String ddd = null;
            String tipoTel = null;
            String numTel;
            String logradouro = null;
            String numLogra = null;
            String complemento = null;
            String tipoEmail = null;
            String descEmail = null;

            Scanner in = new Scanner(System.in);

            System.out.println("Digite o Nome");
            nome = in.nextLine();

            System.out.println("Digite o Sobrenome");
            sobrenome = in.nextLine();

            System.out.println("Digite o numero do DDD");
            ddd = in.nextLine();

            System.out.println("Digite o tipo de telefone");
            tipoTel = in.nextLine();

            System.out.println("Digite o numero do telefone");
            numTel = in.nextLine();

            System.out.println("Digite o logradouro");
            logradouro = in.nextLine();

            System.out.println("Digite o numero da residencia");
            numLogra = in.nextLine();

            System.out.println("Digite o complemento do endereco");
            complemento = in.nextLine();

            System.out.println("Digite o tipo de email: Pessoal ou Comercial");
            tipoEmail = in.nextLine(); 

            System.out.println("Digite o email");
            descEmail = in.nextLine();


            Integer idContato = null;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/agenda", usuario, senha);

            sql = "INSERT INTO CONTATO ( NOME, SOBRENOME) VALUES (?, ?)";
            ps = conn.prepareStatement(sql);

            //salvando contato
            ps.setString(1, nome);
            ps.setString(2, sobrenome);

            ps.execute();
            ps.close();
            conn.close();

            //Pegar contato
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/agenda", usuario, senha);
            sql = "SELECT * FROM contato ORDER BY ID_CONTATO desc LIMIT 1";
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                idContato = rs.getInt("ID_CONTATO");
            }

            ps.close();
            conn.close();        
            System.out.println("IdContato: " + idContato.toString());


            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/agenda", usuario, senha);


            sql = "INSERT INTO TELEFONE (ID_CONTATO, DDD, TIPO_TEL, NUM_TEL) VALUES (?, ?, ?, ?)";
            ps = conn.prepareStatement(sql);

            ps.setInt(1, idContato);
            ps.setString(2, ddd);
            ps.setString(3, tipoTel);
            ps.setString(4, numTel);


            ps.execute();
            ps.close();
            conn.close();

            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/agenda", usuario, senha);

            sql = "INSERT INTO ENDERECO (ID_CONTATO, LOGRADOURO, NUMERO, COMPLEMENTO) VALUES (?, ?, ?, ?)";
            ps = conn.prepareStatement(sql);

            ps.setInt(1, idContato);
            ps.setString(2, logradouro);
            ps.setString(3, numLogra);
            ps.setString(4, complemento);

            ps.execute();
            ps.close();
            conn.close();

            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/agenda", usuario, senha);

            sql = "INSERT INTO EMAIL ( ID_CONTATO, TIPO_EMAIL, DESC_EMAIL) VALUES (?, ?, ?)";
            ps = conn.prepareStatement(sql);

            ps.setInt(1, idContato);
            ps.setString(2, tipoEmail);
            ps.setString(3, descEmail);

            ps.execute();
            ps.close();
            conn.close();
            
        } catch (Exception e) {
            e.printStackTrace();
        }        
    }
 
    public static void consultar(){
        try {
            System.out.println("\n\nListando os Registros Gravados");

            // Leitura do Banco de Dados
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/agenda", usuario, senha);

            sql = "select * from vw_contato";

            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                System.out.println("Nome: " + rs.getString("nome"));
                System.out.println("Sobrenome: " + rs.getString("sobrenome"));
                System.out.println("DDD: " + rs.getString("ddd"));
                System.out.println("Tipo de Telefone: " + rs.getString("tipoTel"));
                System.out.println("Número do telefone: " + rs.getString("numTel"));
                System.out.println("Logradouro: " + rs.getString("logradouro"));
                System.out.println("Numero: " + rs.getString("numLogra"));
                System.out.println("Complemento: " + rs.getString("complemento"));
                System.out.println("Tipo de email.: " + rs.getString("tipoEmail"));
                System.out.println("Email.: " + rs.getString("descEmail"));

            }

            ps.close();
            conn.close();       
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
}